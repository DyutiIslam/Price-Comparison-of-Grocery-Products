## Price Comparison Android Application

[![CircleCI](https://dl.circleci.com/status-badge/img/gh/DidahDx/Price_Comparison_App/tree/master.svg?style=svg)](https://dl.circleci.com/status-badge/redirect/gh/DidahDx/Price_Comparison_App/tree/master)

### PROJECT SETUP
Add firebase to the project and build it.
[Firebase setup android](https://firebase.google.com/docs/android/setup)
The project use:
- firebase authentication(enable email and password and Google logins) [firebase-auth](https://firebase.google.com/docs/auth/android/start),
- firebase database(enable [Realtime database](https://firebase.google.com/docs/database/android/start))

